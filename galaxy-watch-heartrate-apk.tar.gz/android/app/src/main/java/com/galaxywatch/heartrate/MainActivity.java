package com.galaxywatch.heartrate;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
